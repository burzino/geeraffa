package com.example.prova.ripetizioni;

import android.os.Bundle;
import android.app.Activity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextInputLayout textInputLayout=new TextInputLayout(this);
        TextInputEditText editText = new TextInputEditText(textInputLayout.getContext());
    }

}
